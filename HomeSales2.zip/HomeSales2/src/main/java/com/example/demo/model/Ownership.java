package com.example.demo.model;

public class Ownership {
private String ownerType;
private String agentType;
private String approval;
private String purchaseDate;
}
