package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Amenities;

public class AmenitiesServiceImpl implements IAmentiesService {

	@Override
	public List<Amenities> findByCarParking(boolean check) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Amenities> findByparkingType(String type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Amenities> findBylayGround(boolean check) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Amenities> findBynearBusStation(int busDist) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Amenities> findBynearRailStation(int railDist) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Amenities> findBynearSchool(int schoolDist) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Amenities> findBydistToMainRoad(int distMainRoad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Amenities> findBywaterSupplyType(String supplyType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Amenities> findBycommunityHall(boolean commHall) {
		// TODO Auto-generated method stub
		return null;
	}


}
