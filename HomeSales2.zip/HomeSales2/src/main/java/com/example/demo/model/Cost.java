package com.example.demo.model;

public class Cost {
	private double govPrice;
	private double regPrice;
	private double taxPrice;
	private double propertyPrice;
	private boolean loanAvail;
}
