package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Location;

public interface ILocationService {
	List<Location> findBylocId(int locId);
	List<Location> findByst(String st);
	List<Location> findBypincode(int pincode);
	List<Location> findBylandmark(String landmark);
	List<Location> findByArea(String Area);
	List<Location> findBycity(String city);
	List<Location> findBystate(String state);
}
