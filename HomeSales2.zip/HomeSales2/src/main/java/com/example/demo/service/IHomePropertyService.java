package com.example.demo.service;

public interface IHomePropertyService {

}
