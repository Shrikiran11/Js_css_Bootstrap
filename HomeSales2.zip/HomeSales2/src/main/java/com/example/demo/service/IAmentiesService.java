package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Amenities;

public interface IAmentiesService {
	 List<Amenities> findByCarParking(boolean check);
	 List<Amenities> findByparkingType(String type);
	 List<Amenities> findBylayGround(boolean check);
	 List<Amenities> findBynearBusStation(int busDist);
	 List<Amenities> findBynearRailStation(int railDist);
	 List<Amenities> findBynearSchool(int schoolDist);
	 List<Amenities> findBydistToMainRoad(int distMainRoad);
	 List<Amenities> findBywaterSupplyType(String supplyType);
	 List<Amenities> findBycommunityHall(boolean commHall);
}
