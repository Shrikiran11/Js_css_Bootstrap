package com.example.demo.model;

public class PropertyCategory {
 private String buildtype; 
private String yearOfConst;
private String businessType;// residential or commercial
}
