package com.example.demo.service;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;

import com.example.demo.model.Location;
import com.example.demo.repo.ILocationDao;

public class LocationServiceImpl implements ILocationService {

	@Override
	public List<Location> findBylocId(int locId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Location> findByst(String st) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Location> findBypincode(int pincode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Location> findBylandmark(String landmark) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Location> findByArea(String Area) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Location> findBycity(String city) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Location> findBystate(String state) {
		// TODO Auto-generated method stub
		return null;
	}
}
