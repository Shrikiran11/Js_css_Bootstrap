package com.example.demo.model;

public class Visit {
private String visitDays;
private String startTime;
private String endTime;
private boolean dogAlert;
}
