package com.example.demo.model;

import javax.persistence.CascadeType;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;

@Entity
public class HomeProperty {
int homeId;
@NotBlank(message="bhk is mandatory")
int bhk;
String floor;
String paint;
int sqft;
double price;
@ManyToOne(cascade=CascadeType.ALL)
private Location location;
@OneToOne(cascade =CascadeType.ALL)
private Amenities amenities;
@OneToOne(cascade =CascadeType.ALL)
private Cost cost;
@OneToOne(cascade =CascadeType.ALL)
private Ownership ownership;
@OneToOne(cascade =CascadeType.ALL)
private Visit visit;
}
