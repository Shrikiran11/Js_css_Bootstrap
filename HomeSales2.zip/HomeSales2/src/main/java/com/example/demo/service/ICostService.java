package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Cost;

public interface ICostService {
	List<Cost> findBygovPrice(double govPrice);
	List<Cost> findByregPrice(double regPrice);
	List<Cost> findBytaxPrice(double taxPrice);
	List<Cost> findBypropertyPrice(double propertyPrice);
	List<Cost> findByloanAvail(double loanAvail);
}
