package com.example.demo.model;

public class Amenities {
private boolean carParking;
private String parkingType;
private boolean playGround;
private int nearBusStation;
private int nearRailStation;
private int nearSchool;
private int distToMainRoad;
private String waterSupplyType;
private boolean communituHall;

}
