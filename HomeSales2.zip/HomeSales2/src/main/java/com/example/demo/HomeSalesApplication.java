package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeSalesApplication {

	public static void main(String[] args) {
//		@Autowired
//		 HomePropertyServiceImpl homePropertyServiceImpl;
		SpringApplication.run(HomeSalesApplication.class, args);
	}

}
