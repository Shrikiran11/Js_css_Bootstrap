package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Cost;

public class CostServiceImpl implements ICostService{

	@Override
	public List<Cost> findBygovPrice(double govPrice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cost> findByregPrice(double regPrice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cost> findBytaxPrice(double taxPrice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cost> findBypropertyPrice(double propertyPrice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cost> findByloanAvail(double loanAvail) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
