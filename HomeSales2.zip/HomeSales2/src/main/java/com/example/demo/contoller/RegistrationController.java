package com.example.demo.contoller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class RegistrationController {

}
